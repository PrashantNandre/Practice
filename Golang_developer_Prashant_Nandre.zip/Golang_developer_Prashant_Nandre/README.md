How to Run
Prerequisites
Go 1.22+

No database setup required (SQLite auto-creates restaurant.db)

Folder Structure
.
├── cmd/server/main.go        # Entry point
├── internal/                 # App logic (models, db, handlers)
├── restaurant.db             # Auto-generated SQLite DB
├── build/                    # Compiled binary
├── Makefile                  # For automated build/release
└── README.md                 # You’re reading it

make           # Build binary, seed db, zip output
./build/tastybites