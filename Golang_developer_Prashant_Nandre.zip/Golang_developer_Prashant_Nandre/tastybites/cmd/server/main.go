package main

import (
	"fmt"
	"net/http"
	"strings"

	"tastybites/internal/db"
	"tastybites/internal/handler"
	"tastybites/internal/seed"
)

func main() {
	db.Connect("restaurant.db")
	seed.SeedMenu()

	http.HandleFunc("/order", handler.PlaceOrder)

	http.HandleFunc("/admin/table/", func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, "/release") {
			handler.ReleaseTable(w, r)
		} else {
			handler.AdminTableSummary(w, r)
		}
	})

	fmt.Println("🚀 Server listening on http://localhost:8080")
	http.ListenAndServe(":8080", nil)
}
