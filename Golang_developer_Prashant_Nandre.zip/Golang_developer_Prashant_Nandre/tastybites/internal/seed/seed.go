package seed

import (
	"tastybites/internal/db"
	"tastybites/internal/model"
)

func SeedMenu() {
	menu := []model.MenuItem{
		{Name: "Margherita Pizza", Price: 249.00},
		{Name: "Farmhouse Pizza", Price: 299.00},
		{Name: "Garlic Bread", Price: 149.00},
		{Name: "Pepsi", Price: 49.00},
		{Name: "Chocolate Brownie", Price: 119.00},
	}
	for _, item := range menu {
		db.DB.Create(&item)
	}
}
