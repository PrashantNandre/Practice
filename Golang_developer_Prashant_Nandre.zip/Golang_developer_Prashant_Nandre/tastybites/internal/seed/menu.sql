-- Create tables (only needed if not using GORM AutoMigrate)
-- You can skip these if GORM handles schema creation.

-- Insert sample menu items
INSERT INTO menu_items (name, price) VALUES
  ('Margherita Pizza', 249.00),
  ('Farmhouse Pizza', 299.00),
  ('Garlic Bread', 149.00),
  ('Pepsi', 49.00),
  ('Chocolate Brownie', 119.00);
