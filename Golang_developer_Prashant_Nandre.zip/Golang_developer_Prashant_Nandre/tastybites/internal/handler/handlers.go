package handler

import (
	"encoding/json"
	"net/http"
	"strconv"
	"strings"

	"tastybites/internal/db"
	"tastybites/internal/model"

	"gorm.io/gorm"
)

type OrderLine struct {
	MenuItemID uint `json:"menu_item_id"`
	Qty        int  `json:"qty"`
}

type CreateOrderRequest struct {
	UserID  uint        `json:"user_id"`
	TableID uint        `json:"table_id"`
	Items   []OrderLine `json:"items"`
}

func PlaceOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", 405)
		return
	}

	var req CreateOrderRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid JSON", 400)
		return
	}

	var table model.Table
	if err := db.DB.First(&table, req.TableID).Error; err != nil {
		http.Error(w, "Table not found", 404)
		return
	}
	if table.IsReserved {
		http.Error(w, "Table already reserved", 409)
		return
	}

	err := db.DB.Transaction(func(tx *gorm.DB) error {
		table.IsReserved = true
		if err := tx.Save(&table).Error; err != nil {
			return err
		}

		order := model.Order{
			UserID:  req.UserID,
			TableID: table.ID,
			Status:  "PENDING",
		}
		if err := tx.Create(&order).Error; err != nil {
			return err
		}

		var total float64
		for _, line := range req.Items {
			var item model.MenuItem
			if err := tx.First(&item, line.MenuItemID).Error; err != nil {
				return err
			}
			sub := float64(line.Qty) * item.Price
			orderItem := model.OrderItem{
				OrderID:    order.ID,
				MenuItemID: item.ID,
				Quantity:   line.Qty,
				Subtotal:   sub,
			}
			total += sub
			if err := tx.Create(&orderItem).Error; err != nil {
				return err
			}
		}
		order.Total = total
		return tx.Save(&order).Error
	})

	if err != nil {
		http.Error(w, "Error placing order", 500)
		return
	}
	w.WriteHeader(http.StatusCreated)
	w.Write([]byte(`{"status":"order placed"}`))
}

func AdminTableSummary(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", 405)
		return
	}

	tableID, err := extractID(r.URL.Path, "/admin/table/")
	if err != nil {
		http.Error(w, "Invalid path", 400)
		return
	}

	var table model.Table
	if tx := db.DB.Preload("Booking.Items.MenuItem").First(&table, tableID); tx.Error != nil {
		http.Error(w, "Table not found", 404)
		return
	}
	if table.Booking == nil {
		json.NewEncoder(w).Encode(map[string]string{"message": "no active booking"})
		return
	}

	resp := map[string]interface{}{
		"table_id":   table.ID,
		"order_id":   table.Booking.ID,
		"total":      table.Booking.Total,
		"status":     table.Booking.Status,
		"created_at": table.Booking.CreatedAt,
	}
	json.NewEncoder(w).Encode(resp)
}

func ReleaseTable(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", 405)
		return
	}
	tableID, err := extractID(r.URL.Path, "/admin/table/")
	if err != nil {
		http.Error(w, "Invalid path", 400)
		return
	}

	var table model.Table
	if tx := db.DB.First(&table, tableID); tx.Error != nil {
		http.Error(w, "Table not found", 404)
		return
	}
	table.IsReserved = false
	db.DB.Save(&table)
	w.WriteHeader(http.StatusNoContent)
}

// extractID from path like /admin/table/15 or /admin/table/15/release
func extractID(path string, prefix string) (uint, error) {
	clean := strings.TrimPrefix(path, prefix)
	parts := strings.Split(clean, "/")
	return parseUint(parts[0])
}

func parseUint(s string) (uint, error) {
	id, err := strconv.Atoi(s)
	return uint(id), err
}
