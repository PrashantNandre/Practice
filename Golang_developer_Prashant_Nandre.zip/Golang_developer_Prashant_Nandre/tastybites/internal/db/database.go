package db

import (
	"fmt"
	"log"

	"gorm.io/gorm"
	"gorm.io/gorm/logger"

	"github.com/glebarez/sqlite"

	"tastybites/internal/model"
)

var DB *gorm.DB

func Connect(path string) {
	var err error

	DB, err = gorm.Open(sqlite.Open(path), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Silent),
	})
	if err != nil {
		log.Fatal("Failed to connect DB:", err)
	}

	err = DB.AutoMigrate(
		&model.User{},
		&model.Table{},
		&model.MenuItem{},
		&model.Order{},
		&model.OrderItem{},
	)
	if err != nil {
		log.Fatal("Migration failed:", err)
	}

	fmt.Println("SQLite DB ready at", path)
}
