package model

import "time"

// User can make many Orders.
type User struct {
	ID        uint   `gorm:"primaryKey"`
	Name      string `gorm:"size:80;not null"`
	Email     string `gorm:"size:120;uniqueIndex"`
	Phone     string `gorm:"size:15"`
	Orders    []Order
	CreatedAt time.Time
}

// Table
type Table struct {
	ID         uint `gorm:"primaryKey"`
	IsReserved bool `gorm:"index"`
	Booking    *Order
}

// MenuItem
type MenuItem struct {
	ID    uint    `gorm:"primaryKey"`
	Name  string  `gorm:"size:100;not null"`
	Price float64 `gorm:"not null"`
}

// Junction entity so we can store qty.
type OrderItem struct {
	ID         uint `gorm:"primaryKey"`
	OrderID    uint
	MenuItemID uint
	Quantity   int     `gorm:"not null"`
	Subtotal   float64 `gorm:"not null"`
	MenuItem   MenuItem
}

// Order connects User + Table + Items.
type Order struct {
	ID          uint `gorm:"primaryKey"`
	UserID      uint
	TableID     uint
	Total       float64 `gorm:"not null"`
	Status      string  `gorm:"size:20;default:PENDING"`
	Items       []OrderItem
	CreatedAt   time.Time
	CompletedAt *time.Time
}
